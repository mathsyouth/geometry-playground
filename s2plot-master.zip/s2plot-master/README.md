s2plot
======

S2PLOT 3-d graphics API
